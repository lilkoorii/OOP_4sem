﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using SampleMVVM.Models;

namespace SampleMVVM.Data
{
    public class DataContext : DbContext
    {
        public DataContext()
            : base("DbConnection")
        { }

        public DbSet<Consult> consults { get; set; }
    }
}
