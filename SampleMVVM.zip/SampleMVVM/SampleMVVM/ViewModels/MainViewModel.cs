﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;

using SampleMVVM.Commands;
using System.Collections.ObjectModel;
using SampleMVVM.Models;
using System.ComponentModel;

namespace SampleMVVM.ViewModels
{
    class MainViewModel : ViewModelBase, INotifyPropertyChanged
    {
        public ObservableCollection<ConsultViewModel> ConsultsList { get; set; } 

        #region Constructor

        public MainViewModel(List<Consult> consults)
        {
            ConsultsList = new ObservableCollection<ConsultViewModel>(consults.Select(b => new ConsultViewModel(b)));
        }

        /*public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }*/

        #endregion
    }
}
