﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SampleMVVM.Models;
using SampleMVVM.Commands;
using System.Windows.Input;
using SampleMVVM.Data;
using System.Windows;
using System.Data.Entity;
using System.ComponentModel;

namespace SampleMVVM.ViewModels
{
    class ConsultViewModel : ViewModelBase
    {
        public Consult Consult;
        DataContext db;

        public ConsultViewModel(Consult consult)
        {
            this.Consult = consult;
        }

        public int Id
        {
            get
            {
                return Consult.Id;
            }
            set
            {
                Consult.Id = value;
                //OnPropertyChanged("Id");
            }
        }

        public string FIO
        {
            get { return Consult.FIO; }
            set 
            {
                Consult.FIO = value;
                OnPropertyChanged("FIO");
            }
        }

        public string Subject
        {
            get { return Consult.Subject; }
            set
            {
                Consult.Subject = value;
                OnPropertyChanged("Subject");
            }
        }

        public string Date 
        {
            get { return Consult.Date; }
            set
            {
                Consult.Date = value;
                OnPropertyChanged("Date");
            }
        }
        public string Time
        {
            get { return Consult.Time; }
            set
            {
                Consult.Time = value;
                OnPropertyChanged("Time");
            }
        }

        public string Attendance
        {
            get { return Consult.Attendance; }
            set
            {
                Consult.Attendance = value;
                OnPropertyChanged("Attendance");
            }
        }

        /*public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }*/

        #region Commands

        #region Записаться

        private DelegateCommand attendCommand;

        public ICommand AttendCommand
        {
            get
            {
                if (attendCommand == null)
                {
                    attendCommand = new DelegateCommand(Attend, CanAttend);
                }
                return attendCommand;
            }
        }

        private void Attend()
        {
            Attendance = "Да";
            db = new DataContext();
            db.consults.Load();
            Consult cons = new Consult();
            cons = db.consults.Find(Id);
            cons.Attendance = Attendance;
            db.SaveChanges();
            db.Dispose();
        }

        private bool CanAttend()
        {
            return (Attendance.Equals("Нет"));
        }

        #endregion

        #region Отменить запись

        private DelegateCommand cancelAttendCommand;

        public ICommand CancelAttendCommand
        {
            get
            {
                if (cancelAttendCommand == null)
                {
                    cancelAttendCommand = new DelegateCommand(CancelAttend, CanNotAttend);
                }
                return cancelAttendCommand;
            }
        }

        private void CancelAttend()
        {
            Attendance = "Нет";
            db = new DataContext();
            db.consults.Load();
            Consult cons = new Consult();
            cons = db.consults.Find(Id);
            cons.Attendance = Attendance;
            db.SaveChanges();
            db.Dispose();
        }

        private bool CanNotAttend()
        {
            return (Attendance.Equals("Да"));
        }


        #endregion

        #endregion
    }
}
