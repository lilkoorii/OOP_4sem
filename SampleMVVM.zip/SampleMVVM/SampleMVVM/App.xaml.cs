﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using SampleMVVM.Data;
using SampleMVVM.Models;
using SampleMVVM.ViewModels;
using SampleMVVM.Views;

namespace SampleMVVM
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        DataContext db;

        private void OnStartup(object sender, StartupEventArgs e)
        {
            /*List<Consult> consults = new List<Consult>()
            {
                new Consult("Панченко О.Л.", "ООП", "26 мая", "13:00-14:20", "Нет"),
                new Consult("Игнаткова Я.А.", "Веб-дизайн", "25 мая", "11:25-12:45", "Нет"),
                new Consult("Уласевич Н.И.", "Базы данных", "23 мая", "19:40-21:00", "Да")

            };*/

            db = new DataContext();

            db.consults.Load();

            List<Consult> consults = db.consults.ToList();
            MainView view = new MainView();
            MainViewModel viewModel = new ViewModels.MainViewModel(consults);
            view.DataContext = viewModel;
            view.Show();
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            db.Dispose();
        }
    }
}
