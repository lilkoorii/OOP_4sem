﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace SampleMVVM.Models
{
    public class Consult
    {
        [Key]
        public int Id { get; set; }
        public string FIO { get; set; }
        public string Subject { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Attendance { get; set; }

        public Consult(string FIO, string Subject, string Date, string Time, string Attendance)
        {
            this.FIO = FIO;
            this.Subject = Subject;
            this.Date = Date;
            this.Time = Time;
            this.Attendance = Attendance;
        }

        public Consult()
        {
        }
    }
}
